#!/bin/bash
# Flash script for Linux
fastboot erase boot
fastboot flash boot archeion_boot.img
fastboot flash system archeion_system.img
fastboot flash vendor archeion_vendor.img
fastboot flash dtbo archeion_dtbo.img
fastboot reboot