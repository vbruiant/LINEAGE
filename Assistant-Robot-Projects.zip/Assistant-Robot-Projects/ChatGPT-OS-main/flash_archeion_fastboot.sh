#!/bin/zsh
cd ~/archeion_fastboot

echo "📦 Flashing vbmeta..."
fastboot --disable-verity --disable-verification flash vbmeta vbmeta.img

echo "💣 Flashing boot..."
fastboot flash boot boot.img

echo "🧱 Flashing system..."
fastboot flash system system.img

echo "📡 Flashing vendor..."
fastboot flash vendor vendor.img

echo "✅ Flash complete. Rebooting..."
fastboot reboot
