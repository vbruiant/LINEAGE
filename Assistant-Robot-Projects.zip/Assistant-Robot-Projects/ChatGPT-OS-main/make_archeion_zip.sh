#!/bin/zsh
# Génère un ZIP flashable TWRP pour ARCHEION-IN2023

set -e
WORKDIR="$HOME/archeion_zip_build"
IMGSOURCE="$HOME/android_archeion/out"  # Dossier où se trouvent les .img
ZIPNAME="ARCHEION-IN2023-TWRP.zip"

echo "📁 Création de l’arborescence TWRP..."
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR/META-INF/com/google/android"
cd "$WORKDIR"

# Copie des .img
cp "$IMGSOURCE/boot.img" .
cp "$IMGSOURCE/system.img" .
cp "$IMGSOURCE/vendor.img" .
cp "$IMGSOURCE/vbmeta.img" .

# Génération du updater-script
cat > META-INF/com/google/android/updater-script <<EOF
ui_print(">> ARCHEION - OnePlus 8 Pro (IN2023)");
ui_print(">> Format system and vendor...");
run_program("/sbin/mount", "/system");
run_program("/sbin/mount", "/vendor");
format("ext4", "EMMC", "/dev/block/bootdevice/by-name/system", "0");
format("ext4", "EMMC", "/dev/block/bootdevice/by-name/vendor", "0");

ui_print(">> Flashing system...");
package_extract_file("system.img", "/dev/block/bootdevice/by-name/system");

ui_print(">> Flashing vendor...");
package_extract_file("vendor.img", "/dev/block/bootdevice/by-name/vendor");

ui_print(">> Flashing boot...");
package_extract_file("boot.img", "/dev/block/bootdevice/by-name/boot");

ui_print(">> Flashing vbmeta...");
package_extract_file("vbmeta.img", "/dev/block/bootdevice/by-name/vbmeta");

ui_print(">> ARCHEION installation complete.");
EOF

# Génération de l’update-binary factice (stub pour TWRP)
touch META-INF/com/google/android/update-binary
chmod +x META-INF/com/google/android/update-binary

echo "📦 Compression du ZIP..."
zip -r9 "$ZIPNAME" * > /dev/null

echo "✅ ZIP généré : $WORKDIR/$ZIPNAME"
shasum -a 256 "$ZIPNAME"
