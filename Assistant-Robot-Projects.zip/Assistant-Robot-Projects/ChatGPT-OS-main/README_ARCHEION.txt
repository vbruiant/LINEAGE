Instructions for flashing ArcheionOS on OnePlus 8 Pro.
Ensure bootloader is unlocked.
Use Linux or Windows script accordingly.