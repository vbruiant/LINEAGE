#!/bin/zsh
# Extraction ciblée de payload.bin – uniquement les .img essentiels

set -e
WORKDIR="$HOME/android_archeion"
PAYLOAD="payload.bin"

echo "📦 Initialisation de $WORKDIR"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "🔍 Recherche de payload.bin"
FOUND=$(find ~ -name "$PAYLOAD" | head -n 1)
if [ -z "$FOUND" ]; then
    echo "❌ Fichier payload.bin non trouvé."
    exit 1
fi

cp "$FOUND" "$WORKDIR/"
echo "✅ payload.bin copié"

echo "🛠️ Clonage de payload-dumper-go (si nécessaire)"
[ -d "payload-dumper-go" ] || git clone https://github.com/ssut/payload-dumper-go.git
cd payload-dumper-go
go build

echo "📤 Extraction ciblée..."
mkdir -p ../out
./payload-dumper-go -o ../out ../payload.bin

echo "✅ Extraction terminée"
cd ../out
ls -lh boot.img system.img vendor.img vbmeta.img 2>/dev/null || echo "⚠️ Tous les fichiers ne sont peut-être pas présents."

echo "📁 Images extraites prêtes :"
[ -f boot.img ] && echo "✔ boot.img"
[ -f system.img ] && echo "✔ system.img"
[ -f vendor.img ] && echo "✔ vendor.img"
[ -f vbmeta.img ] && echo "✔ vbmeta.img"

echo "📦 Prêt pour la phase 2 : modification ou flash."y

